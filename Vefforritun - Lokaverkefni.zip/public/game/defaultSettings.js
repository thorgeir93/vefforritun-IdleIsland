//
//DEFAULT SETTINGS
//
module.exports = function(){
	return {
		'audio-slider': '20', 
		'annad':'0'
	};
};